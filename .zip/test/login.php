<?php session_start();   $_SESSION["acesso"]=""; ?>

<html>
    <head>
	<title>LOGIN</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<style>
		body{
			background-color: #fff;
		}
	</style>
    </head>
    <body>
	<div class="" style="margin: 10%; background-color: #20c997; border-radius: 2%;">
		<form method="POST" action="logando.php">
			<h1 class="text-center text-light pt-2">LOGIN</h1>
			<div class=" b text-center bg-danger">	
			<?php
			if(@$_GET["erro"]!=""){
				echo @$_GET["erro"];
			}
			?>
			</div>
				<div class="form-group">
					<div class="col-md-6 offset-md-3">
						<label>EMAIL</label>
						<input type="email" name="email" class="form-control" placeholder="email">
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6 offset-md-3">
						<label>SENHA</label>
						<input type="password" name="senha" class="form-control" placeholder="senha">
					</div>
				</div>				
				<p class="text-center">Nao possui uma conta? <a class="text-light"  href="cadastro.php">Cadastre-se</a></p>
				<div class="col-md-6 offset-md-3 pb-2 ">
					<input type="submit" value="Entrar" class="btn btn-secondary" style = "width: 100%"/>
				</div>
		</form>
	</div>	
    </body>
</html>
