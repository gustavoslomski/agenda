<?php
session_start();
if($_SESSION["acesso"]==""){
    header("location: login.php");
}
include 'header.php';
$success = "Cadastro Realizado com Sucesso!";

?>
<html>
<head>
	<title>PAINEL</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<style>
		html{
			overflow-y: hidden;
		}
		body{
			background-color: #fff;
		}
	</style>
</head>
<body>
	
	<div class=" b text-center bg-success">
	<?php	
		if(@$_GET["contato"] == 1){
		 echo $success;
		}
	?>
	</div>
	
	<div style="margin: 15%; background-color: #20c997; border-radius: 2%;" >
		<h1 class="text-center text-light pt-2">Olá <?php echo $_SESSION["nome"]?>, seu login de acesso é: <i><?php echo $_SESSION["email"];?>!</i></h1>
		<!-- <h1 class="text-center text-light pt-2">Olá <?php echo $_SESSION["nome"]; $_SESSION["id_tabela"];?>, voce realizou se cadastro com sucesso.</h1> -->
		<p class="lead text-center p-2">Seja Muito Bem Vindo a Nossa Pagina feita com PHP e HTML para a disciplina de WEB - Profº Dr Wellton</p>

		<!--	<a href="login.php">Sair</a>
			<br>
			<a href="cadastroContato.php">Cadastrar Contato</a>
			<br>
			<a href="mostrarContato.php">Visualizar Contatos</a>
		-->
	</div>
	
</body>
</html>
